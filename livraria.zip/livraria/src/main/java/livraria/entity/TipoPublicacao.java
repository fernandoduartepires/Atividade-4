package livraria.entity;



	public enum TipoPublicacao {
	    IMPRESSO,
	    DIGITAL,
	    AUDIOBOOK
	}
	
	
	
	


package livraria.entity;

import jakarta.persistence.EntityManager;
import jakarta.persistence.EntityManagerFactory;
import jakarta.persistence.Persistence;
import java.math.BigDecimal;

public class App {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

		
		
		
		EntityManagerFactory emf = Persistence.createEntityManagerFactory("livraria-pu");
        EntityManager em = emf.createEntityManager();

        try {
            em.getTransaction().begin();

            Autor autor = new Autor(0, "Machado de Assis", "Brasileiro");
            em.persist(autor);
         
            Editora editora = new Editora(0, "Editora X", "Goiânia");
            em.persist(editora); 

        
            Livro livro = new Livro(
                    0, "Dom Casmurro",
                    1899,
                    "978-85-00-00000-0",
                    new BigDecimal("45.90"),
                    TipoPublicacao.IMPRESSO,
                    autor,
                    editora
            );
            em.persist(livro); 

          
            em.getTransaction().commit();
            System.out.println("O livro, o autor e a editora foram salvos no banco de dados.");

        } catch (Exception e) {
            if (em.getTransaction().isActive()) {
                em.getTransaction().rollback();
            }
            e.printStackTrace();
        } finally {
            em.close();
            emf.close();
        }
    }

		
		
				
	}

